# -*- encoding: utf-8 -*-
"""
License: MIT
Copyright (c) 2019 - present AppSeed.us
"""

from django.contrib.auth.decorators import login_required
from django.shortcuts import render, get_object_or_404, redirect
from django.template import loader
from django.http import HttpResponse
from django import template

from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth import get_user_model
from .resources import PersonResource
from django.http import HttpResponse

import csv

@login_required(login_url="/login/")
def index(request):
    return render(request, "index.html")

@login_required(login_url="/login/")
def pages(request):
    context = {}
    # All resource paths end in .html.
    # Pick out the html file name from the url. And load that template.
    try:
        
        load_template = request.path.split('/')[-1]
        html_template = loader.get_template( load_template )
        return HttpResponse(html_template.render(context, request))
        
    except template.TemplateDoesNotExist:

        html_template = loader.get_template( 'error-404.html' )
        return HttpResponse(html_template.render(context, request))

    except:
    
        html_template = loader.get_template( 'error-500.html' )
        return HttpResponse(html_template.render(context, request))
        
def show_users(request):
     User = get_user_model()
     users = User.objects.all()
     
     #fields_name=User._meta.get_fields()
     
     tmp=[]
     for user in users:
        tmp.append([user.id,user.username,user.password,user.is_superuser, user.email])
     
     
     data={'fields':['id','username','password','is_superuser','email'], 'users': tmp }
     
     return render(request, "tables.html",data)
     
def show_map(request):
     return render(request, "maps.html")
     
@csrf_exempt
def search(request):
    value=request.POST.get('search')
    User = get_user_model()
    users = User.objects.filter(username=value)
     
    tmp=[]
    for user in users:
        tmp.append([user.id,user.username,user.password,user.is_superuser, user.email])
     
    data={'fields':['id','username','password','is_superuser','email'], 'users': tmp }
    
    return render(request, "tables.html", data)
    
@csrf_exempt
def export(request):
    person_resource = PersonResource()
    dataset = person_resource.export()
    
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename=one.csv'
    writer = csv.writer(response)
    
    for data in dataset:
        writer.writerow(data)

    return response 



