# -*- encoding: utf-8 -*-
"""
License: MIT
Copyright (c) 2019 - present AppSeed.us
"""

from django.contrib import admin
from django.urls import path, include  # add this

from apps.views import show_users,show_map,search,export

urlpatterns = [
    path('admin/', admin.site.urls),
    path('users/search',search,name="search"),
    path('users/export',export,name="export"),
    path('users/', show_users),
    path('map/', show_map),
    path("", include("authentication.urls")),  # add this
    path("", include("apps.urls"))  # add this
]
