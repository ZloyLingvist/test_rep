from django.urls import include, path
from . import views

urlpatterns = [
    path('getuser/<username>', views.get_user),
    path('updateuser/<username>', views.update_user),
    path('deleteuser/<username>', views.delete_user),
    path('createWithList', views.createl),
    path('adduser',views.add_user),
    #path('login',views.login)
]