from rest_framework import serializers
from django.contrib.auth import authenticate
from .models import User
from django.contrib.auth.models import PermissionsMixin, AbstractBaseUser, BaseUserManager
import json

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id','name','password')

    extra_kwargs = {
        'password': {'write_only': True}
    }

class UserFullSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ("id","name","firstName","lastName","email","password","phone","userStatus")

    def update(self, instance, validated_data):
        for x in validated_data:
            y = json.loads(x)
            instance.name = y['name']
            instance.firstName = y['firstName']
            instance.lastName = y['lastName']
            instance.email = y["email"]
            instance.password = y['password']
            instance.phone = y['phone']
            instance.userStatus = y['userStatus']
            instance.save()

        return instance


