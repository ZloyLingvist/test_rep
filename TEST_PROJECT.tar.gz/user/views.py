from django.shortcuts import render
from rest_framework.decorators import api_view,action,authentication_classes,permission_classes
from django.http import JsonResponse
from .serializers import UserSerializer,UserFullSerializer
from rest_framework import status
from .models import User
import json
import requests

from rest_framework.response import Response
from rest_framework import serializers
from rest_framework.authentication import SessionAuthentication, BasicAuthentication

from rest_framework.authentication import TokenAuthentication
from rest_framework.authentication import SessionAuthentication, BasicAuthentication
from rest_framework.permissions import IsAuthenticated,AllowAny,IsAdminUser
from django.conf import settings

from oauth2_provider.contrib.rest_framework import (
    IsAuthenticatedOrTokenHasScope,
    OAuth2Authentication,
    TokenHasReadWriteScope,
    TokenHasResourceScope,
    TokenHasScope,
    TokenMatchesOASRequirements,
)


authentication_classes = [OAuth2Authentication]
# Create your views here.

@api_view(["GET"])
def get_user(request,username):
    permission_classes([TokenHasScope])
    user = User.objects.filter(name=username)
    serializer = UserFullSerializer(user, many=True)
    return JsonResponse({'user': serializer.data}, safe=False, status=status.HTTP_200_OK)


@api_view(["POST"])
def add_user(request):
    #authentication_classes = (SessionAuthentication, BasicAuthentication, TokenAuthentication)
    payload = json.loads(request.body)
    pet = User.objects.create(
        name=payload["name"],
        firstName=payload["firstName"],
        lastName=payload["lastName"],
        email=payload["email"],
        password=payload["password"],
        phone=payload["phone"],
        userStatus=payload["userStatus"],
    )
    serializer = UserFullSerializer(pet)
    return JsonResponse({'user': serializer.data}, safe=False, status=status.HTTP_201_CREATED)

@api_view(["POST"])
#@permission_classes([IsAuthenticated,])
def createl(request):
    data=json.loads(request.body)
    for x in data:
        pet = User.objects.create(
            name=x["name"],
            firstName=x["firstName"],
            lastName=x["lastName"],
            email=x["email"],
            password=x["password"],
            phone=x["phone"],
            userStatus=x["userStatus"],
        )
        serializer = UserFullSerializer(pet)
    return JsonResponse({'user': serializer.data}, safe=False, status=status.HTTP_201_CREATED)

@api_view(["PUT"])
#@permission_classes([IsAuthenticated,])
def update_user(request, username):
    user = User.objects.get(name=username)
    serializer = UserFullSerializer(data=request.data)
    serializer.update(instance=user, validated_data=request.data)
    return Response(status=status.HTTP_200_OK)

@api_view(["DELETE"])
#@permission_classes([IsAuthenticated,])
def delete_user(request, username):
    user = User.objects.filter(name=username)
    user.delete()
    return Response(status=status.HTTP_204_NO_CONTENT)


@api_view(['POST'])
@permission_classes([AllowAny])
def login_oath(request):
    with open(settings.CLIENT_DATA, "r", encoding="utf-8") as data:
        mydata = json.load(data)

    #serializer = UserSerializer(data=request.data)
    #if serializer.is_valid():
        #serializer.save()
    r = requests.post('http://0.0.0.0:8000/o/token/',
        data={
            'grant_type': 'client_credentials',
            'username': request.data['name'],
            'password': request.data['password'],
            'client_id': mydata['CLIENT_ID'],
            'client_secret': mydata['CLIENT_SECRET'],
        },
    )

    return Response(r.json())
    #return Response(serializer.errors)


@api_view(['POST'])
@permission_classes([AllowAny])
def token(request):
    with open(settings.CLIENT_DATA, "r", encoding="utf-8") as data:
        mydata = json.load(data)

    r = requests.post(
    'http://0.0.0.0:8000/o/token/',
        data={
            'grant_type': 'client_credentials',
            'username': request.data['name'],
            'password': request.data['password'],
            'client_id': mydata['CLIENT_ID'],
            'client_secret': mydata['CLIENT_SECRET'],
        },
    )

    return JsonResponse({'user': {}}, safe=False, status=status.HTTP_200_OK)
    #return Response(r.json())


#permission_classes=(AllowAny,)
@api_view(['POST'])
@permission_classes([AllowAny])
def revoke_token(request):
    with open(settings.CLIENT_DATA, "r", encoding="utf-8") as data:
        mydata = json.load(data)
    r = requests.post(
        'http://0.0.0.0:8000/o/revoke_token/',
        data={
            'token': request.data['token'],
            'client_id': mydata['CLIENT_ID'],
            'client_secret': mydata['CLIENT_SECRET'],
        },
    )
    # If it goes well return sucess message (would be empty otherwise)
    if r.status_code == requests.codes.ok:
        return Response({'message': 'token revoked'}, r.status_code)
    # Return the error if it goes badly
    return Response(r.json(), r.status_code)