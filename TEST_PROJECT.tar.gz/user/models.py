from django.db import models

from django.db.models.signals import post_save
from django.dispatch import receiver
from rest_framework.authtoken.models import Token
from django.conf import settings
from django.contrib.auth.models import User

from django.contrib.auth.models import PermissionsMixin, AbstractBaseUser, BaseUserManager

class User_manager(BaseUserManager):
    def create_user(self, name, password):
        user = self.model(name=name, firstName='', lastName='', email='',password=password,phone='',userStatus=0)
        user.set_password(password)
        user.save(using=self.db)
        return user

    def create_superuser(self, name, password):
        user = self.create_user(name=name, password=password)
        user.is_superuser = True
        user.is_staff = True
        user.save()
        return user


class User(PermissionsMixin, AbstractBaseUser):
      name = models.CharField(max_length=100,unique=True,)
      firstName = models.CharField(max_length=100,default='',)
      lastName = models.CharField(max_length=100,default='',)
      email = models.EmailField(max_length=100,default='',)
      password = models.CharField(max_length=100,)
      phone = models.CharField(max_length=100,default='',)
      userStatus = models.IntegerField(default=0,)

      is_active = models.BooleanField(default=True)
      is_staff = models.BooleanField(default=False)

      REQUIRED_FIELDS = ["password"]
      USERNAME_FIELD = "name"
      objects = User_manager()

      def __str__(self):
        return self.name



