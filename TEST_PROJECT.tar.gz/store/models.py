from django.db import models
from pet.models import Pet

# Create your models here.
class Store(models.Model):
    petid = models.OneToOneField(Pet,on_delete=models.CASCADE)
    quantity = models.IntegerField()
    shipdate = models.DateTimeField()

    status={
        ('placed','placed'),
        ('approved','approved'),
        ('delivered','delivered')
    }

    status=models.CharField(max_length=100,choices=status,default='placed')
    complete=models.BooleanField()
