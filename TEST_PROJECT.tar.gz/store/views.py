from django.shortcuts import render

# Create your views here.
from django.http import JsonResponse
from rest_framework.decorators import api_view
from .models import Store
import json
from .serializers import StoreSerializer
from rest_framework import status
from .models import Store
from pet.models import Pet
import datetime
from rest_framework.response import Response
from django.db.models import Sum,Count

@api_view(["POST"])
def order(request):
    payload = json.loads(request.body)
    pet = Store.objects.create(
        petid=Pet.objects.get(id=payload["petid"]),
        quantity = payload["quantity"],
        shipdate = datetime.datetime.strptime(payload["shipdate"], '%Y-%m-%d'),
        status=payload["status"],
        complete=payload["complete"]
    )
    serializer = StoreSerializer(pet)
    return JsonResponse({'order': serializer.data}, safe=False, status=status.HTTP_201_CREATED)

@api_view(["GET"])
def get_order(request,order_id):
    order = Store.objects.filter(id=order_id)
    serializer = StoreSerializer(order, many=True)
    return JsonResponse({'order': serializer.data}, safe=False, status=status.HTTP_200_OK)

@api_view(["DELETE"])
def delete_order(request,order_id):
    store = Store.objects.filter(id=order_id)
    store.delete()
    return Response(status=status.HTTP_204_NO_CONTENT)

@api_view(["GET"])
def inventory_order(request):
    queryset = Pet.objects.values('status').annotate(the_count=Count('status'))

    json_data=[]
    for x in queryset:
        data = {}
        data[x['status']] = x['the_count']
        json_data.append(json.dumps(data))

    return JsonResponse({'order': json_data}, safe=False, status=status.HTTP_200_OK)