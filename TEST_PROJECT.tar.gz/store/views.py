from django.shortcuts import render

# Create your views here.
from django.http import JsonResponse
from rest_framework.decorators import api_view
from .models import Store
import json
from .serializers import StoreSerializer
from rest_framework import status
from .models import Store
from pet.models import Pet
import datetime

@api_view(["POST"])
def order(request):
    payload = json.loads(request.body)
    pet = Store.objects.create(
        petid=Pet.objects.get(id=payload["petid"]),
        quantity = payload["quantity"],
        shipdate = datetime.datetime.strptime(payload["shipdate"], '%Y-%m-%d'),
        status=payload["status"],
        complete=payload["complete"]
    )
    serializer = StoreSerializer(pet)
    return JsonResponse({'order': serializer.data}, safe=False, status=status.HTTP_201_CREATED)

@api_view(["GET"])
def get_order(request,order_id):
    order = Store.objects.filter(id=order_id)
    serializer = StoreSerializer(order, many=True)
    return JsonResponse({'order': serializer.data}, safe=False, status=status.HTTP_200_OK)
