from django.urls import include, path
from django.conf import settings
from django.conf.urls.static import static
from . import views

urlpatterns = [
    path('order', views.order),
    path('order/<int:order_id>', views.get_order)
]

