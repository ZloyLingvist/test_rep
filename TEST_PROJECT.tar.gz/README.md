# petstore

Petstore. Django. Swagger.

### Что должно получиться на выходе

https://petstore.swagger.io/

###  Используемое программное обеспечение

Скачать все файлы из репозитория,установить docker и docker compose. Необходимые библиотеки докачаются автоматитически.

- Django

- djangorestframework

- django-cors-headers

- mysqlclient

- Pillow

- django-oauth-toolkit

### Как запускать 

sudo docker-compose up --build - запуск контейнера

sudo docker-compose run --rm web python manage.py migrate

sudo docker-compose run --rm web python manage.py makemigrations


### Примеры тестовых запросов и текущие недоработки

См. файл example

