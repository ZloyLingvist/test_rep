# petstore

Petstore. Django. Swagger.

### Что должно получиться на выходе

https://petstore.swagger.io/

###  Используемое программное обеспечение

Скачать все файлы из репозитория,установить docker и docker compose. Необходимые библиотеки докачаются автоматитически.

- Django

- djangorestframework

- django-cors-headers

- mysqlclient

- Pillow

### Как запускать 
sudo docker-compose up --build - запуск контейнера

sudo docker-compose run --rm web python manage.py migrate

sudo docker-compose run --rm web python manage.py makemigrations


### Недостатки текущей реализации и реализованные методы 
на данном этапе используется стандартная для django БД. 
В будущем нужно перейти к mysql

Функции get_pet_by_id и update_pet_using form отличаются только методом отправки. Пока это две отдельные функции

#### Модуль pet 

add pet - добавление животного в базу. 

delete pet - удаление животного из базы по id 

- Удаление животного из базы данных. БД меняется, но происходит ошибка

update pet - обновление информации о животном по id

get pet - получение всей базы животных

upload Image - просто загрузка изображения через форму без занесения в БД

findbystatus - поиск по массиву статусов

findbyid - поиск по id

#### Модуль user 

!!! Ошибка. Поле userStatus пока текстовое

!!! Update. При обновление обновление БД происходит, но после вылетает ошибка

get_user

add_user
    
createl  - добавление массива пользователей
  
update_user - обновление информации о пользователе

login - зачатки

#### Модуль order

order . Ошибка в том, что shipdata только в формате Y M D

order/id 


### Примеры тестовых запросов

См. файл example

