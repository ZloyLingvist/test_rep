from django.db import models

class ImageModel(models.Model):
    img = models.ImageField(upload_to="images/")

class UploadModel(models.Model):
    id = models.IntegerField(primary_key=True)
    name = models.CharField(max_length=70)
    status = models.CharField(max_length=70)

class Category(models.Model):
    name=models.CharField(max_length=70)

class Tag(models.Model):
    name=models.CharField(max_length=70)

class Pet(models.Model):
    name = models.CharField(max_length=70)
    category= models.OneToOneField(Category,on_delete=models.CASCADE)
    tags = models.OneToOneField(Tag, on_delete=models.CASCADE)

    CHOICES={
        ('available','available'),
        ('pending','pending'),
        ('sold','sold')
    }

    status=models.CharField(max_length=100,choices=CHOICES,default='available')
    photo_url=models.CharField(max_length=100)

    def __str__(self):
        return self.name

