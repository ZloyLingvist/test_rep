from django.db import models

# Create your models here.
class Pet(models.Model):
    name=models.CharField(max_length=70)
    CHOICES={
        ('available','available'),
        ('sold','sold')
    }

    status=models.CharField(max_length=100,choices=CHOICES,default='available')

    def __str__(self):
        return self.name