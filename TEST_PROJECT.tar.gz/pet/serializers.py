from rest_framework import serializers
from .models import Pet,Category,Tag
import json

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = '__all__'

class TagSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tag
        fields = '__all__'

class PetSerializer(serializers.ModelSerializer):
    category=CategorySerializer(required=True)
    tags = TagSerializer(required=True)

    class Meta:
        model = Pet
        fields = '__all__'

    def create(self, validated_data):
        for x in validated_data:
            y = json.loads(x)

            name = y['name']
            status = y['status']
            category_data = y['category']
            tag_data=y['tags']
            photo_url=y['photo_url']

            category = CategorySerializer.create(CategorySerializer(), validated_data=category_data)
            tags = TagSerializer.create(TagSerializer(), validated_data=tag_data)
            pet, created = Pet.objects.update_or_create(name=name,status=status, category=category,photo_url=photo_url,tags=tags)

            return pet

    def update(self,instance,validated_data):
        for x in validated_data:
            y=json.loads(x)

            instance.name = y['name']
            instance.status = y['status']
            instance.photo_url=y['photo_url']
            instance.category.name=y['category']['name']
            instance.tags.name = y['tags']['name']

            instance_cat=Category.objects.get(id=y['category']['id'])
            instance_tag = Tag.objects.get(id=y['tags']['id'])

            instance_cat.name=y['category']['name']
            instance_cat.save()

            instance_tag.name = y['tags']['name']
            instance_tag.save()

            instance.save()

        return instance