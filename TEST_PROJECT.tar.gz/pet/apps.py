from django.apps import AppConfig

class PetConfig(AppConfig):
    name = 'pet'
