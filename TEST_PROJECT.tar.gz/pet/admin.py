from django.contrib import admin
from .models import Pet,Category,Tag,UploadModel

admin.site.register(Tag)
admin.site.register(Category)
admin.site.register(Pet)
admin.site.register(UploadModel)