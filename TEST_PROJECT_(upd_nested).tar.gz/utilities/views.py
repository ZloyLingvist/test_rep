from django.shortcuts import render

# Create your views here.
from rest_framework.decorators import api_view
from django.http import JsonResponse
from rest_framework import status
from pet.models import Category
import json
from rest_framework.response import Response

'''
@api_view(["POST"])
def add_category(request):
    payload = json.loads(request.body)
    obj = Category.objects.create(
        category_name=payload["category_name"],
    )
    serializer = CategorySerializer(obj)
    return JsonResponse({'category': serializer.data}, safe=False, status=status.HTTP_201_CREATED)
'''