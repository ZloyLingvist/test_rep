from django.urls import include, path
from . import views

#urlpatterns = [
    #path('addcategory/', views.add_category),
#]