from rest_framework import serializers
from .models import Pet,Category
import json

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = '__all__'

class PetSerializer(serializers.ModelSerializer):
    category=CategorySerializer(required=True)
    class Meta:
        model = Pet
        fields = '__all__'

    def create(self, validated_data):
        for x in validated_data:
            y = json.loads(x)
            name = y['name']
            status = y['status']
            category_data = y['category']

            category = CategorySerializer.create(CategorySerializer(), validated_data=category_data)
            pet, created = Pet.objects.update_or_create(name=name,status=status,
                                                            category=category)

            return pet

    def update(self,instance,validated_data):
        for x in validated_data:
            y=json.loads(x)

            instance.name = y['name']
            instance.status = y['status']
            instance.category.name=y['category']['name']

            instance_cat=Category.objects.get(id=y['category']['id'])

            instance_cat.name=y['category']['name']
            instance_cat.save()
            instance.save()

        return instance