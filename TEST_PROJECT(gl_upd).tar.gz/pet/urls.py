from django.urls import include, path
from django.conf import settings
from django.conf.urls.static import static
from . import views

urlpatterns = [
    path('addpets', views.add_pets),
    path('getpets', views.get_pets),
    path('updatepets/<int:pet_id>', views.update_pets),
    path('deletepets/<int:pet_id>', views.delete_pets),
    path('<int:pet_id>/upload_image', views.image_upload_view),
    path('findbystatus',views.findbystatus),
    path('<int:pet_id>',views.findbyid)
]

if settings.DEBUG:
        urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)

