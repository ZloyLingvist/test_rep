from django.shortcuts import render

# Create your views here.
from django.http import JsonResponse
from rest_framework.decorators import api_view
from .models import Pet
from rest_framework import status
import json
from .serializers import PetSerializer,CategorySerializer
from rest_framework.response import Response
from django.shortcuts import render
from .forms import ImageForm
import uuid


@api_view(["GET"])
def get_pets(request):
    pet = Pet.objects.all()
    serializer = PetSerializer(pet,many=True)
    return JsonResponse({'pet': serializer.data}, safe=False, status=status.HTTP_200_OK)


@api_view(["PUT"])
def update_pets(request, pet_id):
    #Pet.objects.filter(pk=pet_id).update(name=)
    #payload = json.loads(request.body)
    #pet = Pet.objects.filter(id=pet_id)
    #print('!!!',pet)
    #pet.update(**payload)
    pet = Pet.objects.get(id=pet_id)
    #serializer = PetSerializer(pet)
    #return JsonResponse({'pet': serializer.data}, safe=False, status=status.HTTP_200_OK)
    serializer = PetSerializer(data=request.data)
    serializer.update(instance=pet,validated_data=request.data)
    return Response(status=status.HTTP_200_OK)
    #return JsonResponse({'pet': serializer.data}, safe=False, status=status.HTTP_200_OK)


@api_view(["POST"])
def add_pets(request):
    serializer=PetSerializer(data=request.data)
    serializer.create(validated_data=request.data)
    return JsonResponse({'pet': serializer.data}, safe=False, status=status.HTTP_200_OK)


@api_view(["DELETE"])
def delete_pets(request, pet_id):
    user = request.user.id
    pet = Pet.objects.filter(id=pet_id)
    pet.delete()
    return Response(status=status.HTTP_204_NO_CONTENT)

@api_view(["GET"])
def findbystatus(request):
    data=request.data
    for x in data:
        x=x[1:-1].split(",")
        pet = Pet.objects.filter(status__in=x)
        serializer = PetSerializer(pet, many=True)
        return JsonResponse({'pet': serializer.data}, safe=False, status=status.HTTP_200_OK)

    return Response(status=status.HTTP_200_OK)

@api_view(["GET"])
def findbyid(request,pet_id):
    pet = Pet.objects.filter(id=pet_id)
    serializer = PetSerializer(pet, many=True)
    return JsonResponse({'pet': serializer.data}, safe=False, status=status.HTTP_200_OK)


def image_upload_view(request,pet_id):
    """Process images uploaded by users"""
    if request.method == 'POST':
        form = ImageForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            img_obj = form.instance

            pet = Pet.objects.get(id=pet_id)
            pet.photo_url="media/image/"+str(uuid.uuid4())
            pet.save()

            return render(request, 'home.html', {'form': form, 'img_obj': img_obj})
    else:
        form = ImageForm()
    return render(request, 'home.html', {'form': form})