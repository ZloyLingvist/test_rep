# petstore

Petstore. Django. Swagger.

### Что должно получиться на выходе

https://petstore.swagger.io/

###  Используемое программное обеспечение

Скачать все файлы из репозитория,установить docker и docker compose. Необходимые библиотеки докачаются автоматитически.

- Django

- djangorestframework

- django-cors-headers

- mysqlclient

- Pillow

### Как запускать 
sudo docker-compose up --build - запуск контейнера

sudo docker-compose run --rm web python manage.py migrate

sudo docker-compose run --rm web python manage.py makemigrations


### Недостатки текущей реализации и реализованные методы 

на данном этапе используется стандартная для django БД. 
В будущем нужно перейти к mysql

#### Модуль pet 

add pet - добавление животного в базу. 

- Реализованы не все поля.

delete pet - удаление животного из базы по id 

- Удаление животного из базы данных. БД меняется, но происходит ошибка

update pet - обновление информации о животном по id

get pet - получение всей базы животных

upload Image - просто загрузка изображения через форму без занесения в БД

findbystatus - поиск по массиву статусов

findbyid - поиск по id

#### Модуль user (данной таблице нужна migrate)

!!! Ошибка. Поле userStatus пока текстовое

!!! Update. При обновление обновление БД происходит, но после вылетает ошибка

get_user

add_user
    
createl  - добавление массива пользователей
  
update_user - обновление информации о пользователе

login - зачатки


### Примеры тестовых запросов

 http://0.0.0.0:8000/pet/1/upload_image

 curl -X POST -d '{"name":"tes","category":{"name":"test55"},"tags":{"name":"test44"},"status":"sold","photo_url":"test"}' http://0.0.0.0:8000/pet/addpets

 curl -X DELETE -d '' http://0.0.0.0:8000/pet/deletepets/3

 curl -X PUT -d '{"name":"animal","category":{"id":"1","name":"category_type"},"tags":{"id":"2","name":"tag_type"},"status":"sold","photo_url":"test"}' http://0.0.0.0:8000/pet/updatepets/3
 
 curl -X GET -d '' http://0.0.0.0:8000/pet/getpets
 
 curl -X GET -d '['sold','unsold']' http://0.0.0.0:8000/pet/findbystatus

 curl -X GET -d '' http://0.0.0.0:8000/pet/4
 
 curl -X POST -d '{"name":"rashid55","firstName":"rashid","lastName":"Samatov","email":"rashid@mail.ru","password":"12345","phone":"999","userStatus":'1'}' http://0.0.0.0:8000/user/adduser
 
 curl -X GET -d '' http://0.0.0.0:8000/user/getuser/rashid55
 
 curl -X DELETE -d '' http://0.0.0.0:8000/user/deleteuser/rashid45
 
 curl -X PUT -d '{"name":"testerrashid55","firstName":"rashid","lastName":"Samatov","email":"rashid55@mail.ru","password":"123456","phone":"999","userStatus":'1'}' http://0.0.0.0:8000/user/updateuser/rashid55

 curl -X POST -d '[{"name":"ivan","firstName":"ivanov","lastName":"ivanov","email":"van@mail.ru","password":"m122345","phone":"66999","userStatus":'2'},
 {"name":"petr","firstName":"petrovich","lastName":"petrov","email":"pes@mail.ru","password":"p122345","phone":"66999","userStatus":'2'},
 {"name":"semen","firstName":"semenovich","lastName":"semenov","email":"sem@mail.ru","password":"p122345","phone":"66999","userStatus":'2'}]' http://0.0.0.0:8000/user/createWithList
 




