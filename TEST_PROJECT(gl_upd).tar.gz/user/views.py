from django.shortcuts import render
from rest_framework.decorators import api_view
from django.http import JsonResponse
from .serializers import UserSerializer
from rest_framework import status
from .models import User
import json
from rest_framework.response import Response

# Create your views here.
@api_view(["GET"])
def get_user(request,username):
    user = User.objects.filter(name=username)
    serializer = UserSerializer(user, many=True)
    return JsonResponse({'user': serializer.data}, safe=False, status=status.HTTP_200_OK)

@api_view(["POST"])
def add_user(request):
    payload = json.loads(request.body)
    pet = User.objects.create(
        name=payload["name"],
        firstName=payload["firstName"],
        lastName=payload["lastName"],
        email=payload["email"],
        password=payload["password"],
        phone=payload["phone"],
        userStatus=payload["userStatus"],
    )
    serializer = UserSerializer(pet)
    return JsonResponse({'user': serializer.data}, safe=False, status=status.HTTP_201_CREATED)

@api_view(["POST"])
def createl(request):
    data=json.loads(request.body)
    for x in data:
        pet = User.objects.create(
            name=x["name"],
            firstName=x["firstName"],
            lastName=x["lastName"],
            email=x["email"],
            password=x["password"],
            phone=x["phone"],
            userStatus=x["userStatus"],
        )
        serializer = UserSerializer(pet)
    return JsonResponse({'user': serializer.data}, safe=False, status=status.HTTP_201_CREATED)

@api_view(["PUT"])
def update_user(request, username):
    payload = json.loads(request.body)
    pet = User.objects.filter(name=username)
    pet.update(**payload)
    serializer = UserSerializer(pet)
    return JsonResponse({'user': serializer.data}, safe=False, status=status.HTTP_200_OK)

@api_view(["DELETE"])
def delete_user(request, username):
    user = User.objects.filter(name=username)
    user.delete()
    return Response(status=status.HTTP_204_NO_CONTENT)

@api_view(['GET'])
def login(request, format=None):
    content = {
        'user': str.encode(request.user,encoding='utf-8'),  # `django.contrib.auth.User` instance.
        'auth': str.encode(request.auth,encoding='utf-8'),  # None
    }
    return Response(content)
