from django.shortcuts import render

# Create your views here.
from django.http import JsonResponse
from rest_framework.decorators import api_view
from .models import Pet
from rest_framework import status
import json
from .serializers import PetSerializer
from rest_framework.response import Response


@api_view(["GET"])
def get_pets(request):
    pet = Pet.objects.all()
    serializer = PetSerializer(pet, many=True)
    return JsonResponse({'pet': serializer.data}, safe=False, status=status.HTTP_200_OK)


@api_view(["PUT"])
def update_pets(request, pet_id):
    payload = json.loads(request.body)
    pet = Pet.objects.filter(id=pet_id)
    pet.update(**payload)
    pet = Pet.objects.get(id=pet_id)
    serializer = PetSerializer(pet)
    return JsonResponse({'pet': serializer.data}, safe=False, status=status.HTTP_200_OK)


@api_view(["POST"])
def add_pets(request):
    payload = json.loads(request.body)
    pet = Pet.objects.create(
        name=payload["name"],
        status=payload["status"],
    )
    serializer = PetSerializer(pet)
    return JsonResponse({'pet': serializer.data}, safe=False, status=status.HTTP_201_CREATED)

@api_view(["DELETE"])
def delete_pets(request, pet_id):
    user = request.user.id
    pet = Pet.objects.filter(id=pet_id)
    pet.delete()
    return Response(status=status.HTTP_204_NO_CONTENT)

