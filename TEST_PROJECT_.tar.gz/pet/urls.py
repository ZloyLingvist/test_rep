from django.urls import include, path
from . import views

urlpatterns = [
    path('getpets', views.get_pets),
    path('updatepets/<int:pet_id>', views.update_pets),
    path('deletepets/<int:pet_id>', views.delete_pets),
    path('addpets', views.add_pets),
]